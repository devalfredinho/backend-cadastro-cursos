const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '..', 'public', 'cursos.json');

function lerCursos() {
  const data = fs.readFileSync(filePath);
  return JSON.parse(data);
}

function salvarCursos(cursos) {
  fs.writeFileSync(filePath, JSON.stringify(cursos, null, 2));
}

module.exports = {
  getAll: () => lerCursos(),

  getById: (id) => {
    const cursos = lerCursos();
    return cursos.find(c => c.id === id);
  },

  create: (novoCurso) => {
    const cursos = lerCursos();
    novoCurso.id = cursos.length ? cursos[cursos.length - 1].id + 1 : 1;
    cursos.push(novoCurso);
    salvarCursos(cursos);
    return novoCurso;
  },

  update: (id, dadosAtualizados) => {
    const cursos = lerCursos();
    const index = cursos.findIndex(c => c.id === id);
    if (index === -1) return null;
    cursos[index] = { id, ...dadosAtualizados };
    salvarCursos(cursos);
    return cursos[index];
  },

  remove: (id) => {
    const cursos = lerCursos();
    const novoArray = cursos.filter(c => c.id !== id);
    salvarCursos(novoArray);
  }
};