const Curso = require('../models/cursoModel');

exports.listar = (req, res) => res.json(Curso.getAll());

exports.buscarPorId = (req, res) => {
  const curso = Curso.getById(Number(req.params.id));
  if (!curso) return res.status(404).json({ erro: 'Curso não encontrado' });
  res.json(curso);
};

exports.criar = (req, res) => {
  const curso = Curso.create(req.body);
  res.status(201).json(curso);
};

exports.atualizar = (req, res) => {
  const curso = Curso.update(Number(req.params.id), req.body);
  if (!curso) return res.status(404).json({ erro: 'Curso não encontrado' });
  res.json(curso);
};

exports.excluir = (req, res) => {
  Curso.remove(Number(req.params.id));
  res.status(204).send();
};